import discord
from discord import app_commands
from discord.ui import Button, View, Modal, TextInput
import random
import string
import json
import os
from datetime import datetime

intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

ALLOWED_USER_ID = 1488079092048990358

# Database files
KEYS_FILE = "keys.json"
BLACKLIST_FILE = "blacklist.json"

# Load/Save functions
def load_json(file):
    if os.path.exists(file):
        with open(file, 'r') as f:
            return json.load(f)
    return {}

def save_json(file, data):
    with open(file, 'w') as f:
        json.dump(data, f, indent=4)

def generate_key():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choices(characters, k=30))

def hash_hwid(hwid):
    import hashlib
    return hashlib.sha256(hwid.encode()).hexdigest()

# ==================== MODALS ====================

class ResetHWIDModal(Modal):
    def __init__(self):
        super().__init__(title="Reset HWID")
        self.key_input = TextInput(
            label="Enter Key",
            placeholder="Paste the key here...",
            required=True,
            style=discord.TextStyle.short
        )
        self.add_item(self.key_input)

    async def on_submit(self, interaction: discord.Interaction):
        key = self.key_input.value.strip()
        keys = load_json(KEYS_FILE)
        
        if key not in keys:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="Error",
                    description="Key not found in database.",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        old_hwid = keys[key].get("hwid", "None")
        keys[key]["hwid"] = None
        save_json(KEYS_FILE, keys)
        
        await interaction.response.send_message(
            embed=discord.Embed(
                title="HWID Reset Successfully",
                description=f"**Key:** `{key}`\n**Old HWID:** `{old_hwid}`\n**Status:** HWID has been cleared.",
                color=discord.Color.green()
            ),
            ephemeral=True
        )

class BlacklistModal(Modal):
    def __init__(self):
        super().__init__(title="Blacklist Key")
        self.key_input = TextInput(
            label="Enter Key to Blacklist",
            placeholder="Paste the key here...",
            required=True,
            style=discord.TextStyle.short
        )
        self.reason_input = TextInput(
            label="Reason (optional)",
            placeholder="Reason for blacklisting...",
            required=False,
            style=discord.TextStyle.paragraph
        )
        self.add_item(self.key_input)
        self.add_item(self.reason_input)

    async def on_submit(self, interaction: discord.Interaction):
        key = self.key_input.value.strip()
        reason = self.reason_input.value.strip() or "No reason provided"
        
        blacklist = load_json(BLACKLIST_FILE)
        blacklist[key] = {
            "reason": reason,
            "date": str(datetime.now())
        }
        save_json(BLACKLIST_FILE, blacklist)
        
        await interaction.response.send_message(
            embed=discord.Embed(
                title="Key Blacklisted",
                description=f"**Key:** `{key}`\n**Reason:** {reason}\n**Status:** Blacklisted",
                color=discord.Color.red()
            ),
            ephemeral=True
        )

class UnblacklistModal(Modal):
    def __init__(self):
        super().__init__(title="Unblacklist Key")
        self.key_input = TextInput(
            label="Enter Key to Unblacklist",
            placeholder="Paste the key here...",
            required=True,
            style=discord.TextStyle.short
        )
        self.add_item(self.key_input)

    async def on_submit(self, interaction: discord.Interaction):
        key = self.key_input.value.strip()
        blacklist = load_json(BLACKLIST_FILE)
        
        if key in blacklist:
            del blacklist[key]
            save_json(BLACKLIST_FILE, blacklist)
            
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="Key Unblacklisted",
                    description=f"**Key:** `{key}`\n**Status:** Removed from blacklist",
                    color=discord.Color.green()
                ),
                ephemeral=True
            )
        else:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="Error",
                    description="Key not found in blacklist.",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )

class KeyInfoModal(Modal):
    def __init__(self):
        super().__init__(title="Key Information")
        self.key_input = TextInput(
            label="Enter Key",
            placeholder="Paste the key here...",
            required=True,
            style=discord.TextStyle.short
        )
        self.add_item(self.key_input)

    async def on_submit(self, interaction: discord.Interaction):
        key = self.key_input.value.strip()
        keys = load_json(KEYS_FILE)
        blacklist = load_json(BLACKLIST_FILE)
        
        if key not in keys:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="Error",
                    description="Key not found.",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        key_data = keys[key]
        is_blacklisted = key in blacklist
        
        embed = discord.Embed(
            title="Key Information",
            color=0xFFFFFE if not is_blacklisted else discord.Color.red()
        )
        embed.add_field(name="Key", value=f"`{key}`", inline=False)
        embed.add_field(name="HWID Bound", value=f"`{key_data.get('hwid', 'None')}`", inline=True)
        embed.add_field(name="Created", value=key_data.get('created_at', 'Unknown'), inline=True)
        embed.add_field(name="Blacklisted", value=str(is_blacklisted), inline=True)
        
        if is_blacklisted:
            embed.add_field(name="Blacklist Reason", value=blacklist[key].get('reason', 'N/A'), inline=False)
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

class GenerateKeyModal(Modal):
    def __init__(self):
        super().__init__(title="Generate Keys")
        self.amount_input = TextInput(
            label="Number of Keys",
            placeholder="1-10",
            required=True,
            style=discord.TextStyle.short,
            min_length=1,
            max_length=2
        )
        self.add_item(self.amount_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            amount = int(self.amount_input.value.strip())
            if amount < 1 or amount > 10:
                await interaction.response.send_message(
                    embed=discord.Embed(
                        title="Error",
                        description="Please enter a number between 1 and 10.",
                        color=discord.Color.red()
                    ),
                    ephemeral=True
                )
                return
        except ValueError:
            await interaction.response.send_message(
                embed=discord.Embed(
                    title="Error",
                    description="Please enter a valid number.",
                    color=discord.Color.red()
                ),
                ephemeral=True
            )
            return
        
        keys = load_json(KEYS_FILE)
        generated_keys = []
        
        for _ in range(amount):
            key = generate_key()
            keys[key] = {
                "hwid": None,
                "created_at": str(datetime.now()),
                "active": True
            }
            generated_keys.append(key)
        
        save_json(KEYS_FILE, keys)
        
        keys_text = "\n".join([f"`{k}`" for k in generated_keys])
        
        await interaction.response.send_message(
            embed=discord.Embed(
                title=f"Generated {amount} Key(s)",
                description=keys_text,
                color=0xFFFFFE
            ),
            ephemeral=True
        )

# ==================== PANEL VIEW ====================

class PanelView(View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Generate Key", style=discord.ButtonStyle.green, emoji="🔑", custom_id="panel_generate")
    async def generate_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != ALLOWED_USER_ID:
            await interaction.response.send_message("Access Denied", ephemeral=True)
            return
        await interaction.response.send_modal(GenerateKeyModal())
    
    @discord.ui.button(label="Reset HWID", style=discord.ButtonStyle.blurple, emoji="🔄", custom_id="panel_resethwid")
    async def reset_hwid_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != ALLOWED_USER_ID:
            await interaction.response.send_message("Access Denied", ephemeral=True)
            return
        await interaction.response.send_modal(ResetHWIDModal())
    
    @discord.ui.button(label="Blacklist Key", style=discord.ButtonStyle.red, custom_id="panel_blacklist")
    async def blacklist_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != ALLOWED_USER_ID:
            await interaction.response.send_message("Access Denied", ephemeral=True)
            return
        await interaction.response.send_modal(BlacklistModal())
    
    @discord.ui.button(label="Unblacklist Key", style=discord.ButtonStyle.gray, custom_id="panel_unblacklist")
    async def unblacklist_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != ALLOWED_USER_ID:
            await interaction.response.send_message("Access Denied", ephemeral=True)
            return
        await interaction.response.send_modal(UnblacklistModal())
    
    @discord.ui.button(label="Key Info", style=discord.ButtonStyle.gray, custom_id="panel_info")
    async def keyinfo_button(self, interaction: discord.Interaction, button: Button):
        if interaction.user.id != ALLOWED_USER_ID:
            await interaction.response.send_message("Access Denied", ephemeral=True)
            return
        await interaction.response.send_modal(KeyInfoModal())

# ==================== COMMANDS ====================

@tree.command(name="panel", description="Send the control panel")
async def panel(interaction: discord.Interaction):
    if interaction.user.id != ALLOWED_USER_ID:
        await interaction.response.send_message(
            embed=discord.Embed(
                title="Access Denied",
                description="You are not authorized to use this command.",
                color=discord.Color.red()
            ),
            ephemeral=True
        )
        return
    
    embed = discord.Embed(
        title= " Core Script Keys Panel",
        description=(
            "Use the buttons below to manage the keys.\n\n"
            "** Generate Key** - Generate new license keys\n"
            "** Reset HWID** - Reset the HWID of a key\n"
            "** Blacklist** - Ban a key from being used\n"
            "** Unblacklist** - Remove a key from blacklist\n"
            "** Key Info** - View key details\n\n"

            "**Notes for Client:** To reset your **HWID** contact Support."
        ),
        color=0xFFFFFE
    )
    embed.set_footer(text="Only authorized users can use these buttons")
    
    await interaction.response.send_message(embed=embed, view=PanelView())

# ==================== WEB SERVER ====================
from aiohttp import web

async def handle_validate(request):
    try:
        data = await request.json()
        key = data.get('key')
        hwid = data.get('hwid')
        
        if not key or not hwid:
            return web.json_response({"status": "error", "message": "Missing key or HWID"})
        
        keys = load_json(KEYS_FILE)
        blacklist = load_json(BLACKLIST_FILE)
        
        if key in blacklist:
            return web.json_response({"status": "error", "message": "Key is blacklisted"})
        
        if key not in keys:
            return web.json_response({"status": "error", "message": "Invalid key"})
        
        hashed_hwid = hash_hwid(hwid)
        
        if keys[key]["hwid"] is None:
            keys[key]["hwid"] = hashed_hwid
            save_json(KEYS_FILE, keys)
            return web.json_response({"status": "success", "message": "HWID bound successfully"})
        
        elif keys[key]["hwid"] == hashed_hwid:
            return web.json_response({"status": "success", "message": "HWID matches"})
        
        else:
            return web.json_response({"status": "error", "message": "Key already bound to different HWID"})
    
    except Exception as e:
        return web.json_response({"status": "error", "message": str(e)})

async def start_web_server():
    app = web.Application()
    app.router.add_post('/validate', handle_validate)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', 8080)
    await site.start()
    print("Web server started on port 8080")

@client.event
async def on_ready():
    try:
        # Register persistent views
        client.add_view(PanelView())
        
        synced = await tree.sync()
        print(f"Logged in as {client.user} | Synced {len(synced)} commands")
        await start_web_server()
    except Exception as e:
        print(f"Error: {e}")
client.run('MTQ5NzY4NTM1OTcwMDczODE1OA.Go-DoZ.giJARqFk_22OUebSHLGP1riqyMz785ZyRhKx88')